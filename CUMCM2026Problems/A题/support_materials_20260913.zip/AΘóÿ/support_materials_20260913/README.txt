Support materials listed in paper appendix: core code, four result workbooks, and AI usage details.
